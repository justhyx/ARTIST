﻿namespace LL.EAAddin.IntegrationArchitect.Plugin.Uml2EmfExporter
{
	internal enum Actions
	{
		None,
		XMIExport,
		Connecting,
		DataTransfer,
	}
}
