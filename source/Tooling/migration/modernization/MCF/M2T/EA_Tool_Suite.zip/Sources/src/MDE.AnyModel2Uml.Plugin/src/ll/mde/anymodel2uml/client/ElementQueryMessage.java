package ll.mde.anymodel2uml.client;

public class ElementQueryMessage
{
    public String Guid;    
}
