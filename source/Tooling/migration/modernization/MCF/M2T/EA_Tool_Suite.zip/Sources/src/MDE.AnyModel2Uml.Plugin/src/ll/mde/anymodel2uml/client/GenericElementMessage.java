package ll.mde.anymodel2uml.client;

public class GenericElementMessage
{
    public static class Property
    {
        public String Name;
        public Object[] Value;
    }
    
    public Property[] Properties;
}
